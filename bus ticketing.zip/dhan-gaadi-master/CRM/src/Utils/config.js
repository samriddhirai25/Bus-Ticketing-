export const API = process.env.REACT_APP_API_URL;
export const JWT_SECRET = process.env.REACT_APP_JWT_SECRET;
export const SERVER_ROUTE = process.env.REACT_APP_SERVER_ROUTE;
export const API_URL = process.env.REACT_APP_API_URL;
export const busKey = 'sidebarBuses';
export const peopleKey = 'sidebarPeople';
export const jwtKey = 'jwt';
