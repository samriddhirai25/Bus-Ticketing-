
import React from 'react';

export default loading => loading && <img src="/img/spinner.gif" alt="" className="spinner" />;
