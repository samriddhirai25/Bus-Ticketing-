import React from 'react';

export default error => error && <div className="alert alert-danger">{error}</div>;
