export const API = 'http://localhost:8525/api';
export const API_ROOT = 'http://localhost:8525';