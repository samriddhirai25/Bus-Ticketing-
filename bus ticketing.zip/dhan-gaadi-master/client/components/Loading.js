
export default loading => loading && <img src="/static/img/spinner.gif" alt="" className="spinner" />;
