const { seedSuperAdmin } = require("./superadmin");

const runSeed = () => {
  seedSuperAdmin();
};

module.exports = runSeed;
