export const SIGN_IN = 'sign_in';
export const SIGN_OUT = 'sign_out';
export const JOURNEY_TYPE = 'journey_type';