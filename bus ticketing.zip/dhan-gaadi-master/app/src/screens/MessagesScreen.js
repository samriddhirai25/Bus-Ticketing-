import React, { Component } from 'react'
import { Text, View } from 'react-native'

export class MessagesScreen extends Component {
    render() {
        return (
            <View>
                <Text> Message Screen </Text>
            </View>
        )
    }
}

export default MessagesScreen
