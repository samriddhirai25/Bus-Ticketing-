import React, { Component } from 'react'
import { Text, View } from 'react-native'

export class SettingScreen extends Component {

    // componentDidMount() {
    //     this.props.navigation.setOptions({ title: "Setting" });
    //   }

    render() {
        return (
            <View>
                <Text> Setting Screen </Text>
                <Text> Setting Screen </Text>
                <Text> Setting Screen </Text>
                <Text> Setting Screen </Text>
                <Text> Setting Screen </Text>
                <Text> Setting Screen </Text>
            </View>
        )
    }
}

export default SettingScreen
